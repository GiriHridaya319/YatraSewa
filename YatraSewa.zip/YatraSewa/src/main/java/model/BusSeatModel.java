package model;

public class BusSeatModel {

}
